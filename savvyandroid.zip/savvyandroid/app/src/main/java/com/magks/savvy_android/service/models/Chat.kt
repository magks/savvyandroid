package com.magks.savvy_android.service.models

abstract class ChatUser
abstract class ChatMessage
