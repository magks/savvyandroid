package com.magks.savvy_android.util

class AppConstants{
}
