package com.magks.savvy_android.Views


import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModel
import android.arch.lifecycle.ViewModelProviders
import android.content.Intent
import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v7.app.AppCompatActivity
import android.support.design.widget.BottomNavigationView.OnNavigationItemSelectedListener

import android.support.v7.widget.Toolbar
import android.view.View

import android.view.Window
import android.view.WindowManager
import android.widget.*
import com.magks.savvy_android.R
import com.magks.savvy_android.ViewModels.GameDashboardViewModel
import com.magks.savvy_android.ViewModels.ToolbarViewModel


class MainActivity : AppCompatActivity() {

    val toolbarViewModel = ViewModelProviders.of(this).get(ToolbarViewModel::class.java)
    val gameDashboardViewModel = ViewModelProviders.of(this).get(GameDashboardViewModel::class.java)
    private lateinit var textMessage: TextView
    private val onNavigationItemSelectedListener = OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_dashboard_help -> {
                textMessage.setText(R.string.dashboard_help)
                return@OnNavigationItemSelectedListener true
            }

        }
        false
    }

    fun startProfileActivity(view: View){
        val intent = Intent(this, ProfileActivity::class.java)
        toolbarViewModel.isEnteringProfileActivity()
        startActivity(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Data binding
        // Fullscreen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //val binding : ActivityMainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        //setContentView(R.layout.activity_main)
        // Hide default actionbar
       // supportActionBar?.hide()

        // Bottom Nav
        val navView = findViewById<BottomNavigationView>(R.id.nav_view)
        navView.setOnNavigationItemSelectedListener(onNavigationItemSelectedListener)

        //Toolbar
        val toolbar = findViewById<Toolbar>(R.id.game_dashboard_toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        // Game dashboard fragment
        supportFragmentManager.beginTransaction().add(
            R.id.game_dashboard_frame_layout,
            GameDashboardFragment()
        ).commit()

        // Viewmodel: main game waiting dashboard
        gameDashboardViewModel.playerList.observe(this, Observer {
            it?.let {
                // do some thing with the list
            }
        })

        // Viewmodel: toolbar

    }



    /**
     * @param toolbar toolbar
     * @param resId 图片资源id
     * @return 被添加的ImageView
     */
    fun addButtonToToolbar(toolbar: Toolbar?, resId: Int, width:Int, height: Int, gravity: Int): ImageView? {
        if (toolbar == null) {
            Toast.makeText(this, "Toolbar is null!", Toast.LENGTH_LONG).show()
            return null
        }
        val context = toolbar.context
        val img = ImageView(
            context
        )
        img.setImageResource(resId)
        img.scaleType = ImageView.ScaleType.CENTER_INSIDE

        val params = Toolbar.LayoutParams(width, height, gravity)
        img.setLayoutParams(params)
        toolbar.addView(img)
        return img
    }

}
