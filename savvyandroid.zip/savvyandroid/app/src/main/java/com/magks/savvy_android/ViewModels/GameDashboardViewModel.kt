package com.magks.savvy_android.ViewModels

import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel;

class GameDashboardViewModel : ViewModel() {
    // TODO: Implement the ViewModel
    val playerList = MutableLiveData<List<Int>>() //Change to List<Players> or similar metaphor
}
