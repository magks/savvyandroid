package com.magks.savvy_android.viewmodels

import androidx.lifecycle.ViewModel;

class MatchesChatViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
