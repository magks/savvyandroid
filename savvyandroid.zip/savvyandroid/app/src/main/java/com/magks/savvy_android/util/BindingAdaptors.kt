package com.magks.savvy_android.util

import android.widget.ImageButton
import android.databinding.BindingAdapter
import android.view.View

object BindingAdapters {
    /**
     * A Binding Adapter that is called whenever the value of the attribute `app:goneUnless`
     * changes and sets
     */
    @BindingAdapter("app:goneUnless")
    @JvmStatic fun goneUnless(imageButton: ImageButton, visible: Boolean) {
        imageButton.visibility = if (visible) View.VISIBLE else View.GONE
    }
}