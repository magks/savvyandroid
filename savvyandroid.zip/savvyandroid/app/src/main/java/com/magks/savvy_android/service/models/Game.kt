package com.magks.savvy_android.service.models


abstract class CurrentGame
abstract class Player
abstract class Question
abstract class Answer
abstract class Invitation


// my own extension, encapsulating a given Round's data thought this might be collapsed into "CurrentGame"
abstract class Round



