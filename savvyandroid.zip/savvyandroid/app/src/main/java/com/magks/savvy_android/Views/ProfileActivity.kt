package com.magks.savvy_android.Views

import android.arch.lifecycle.ViewModelProviders
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.view.Window
import android.view.WindowManager
import com.magks.savvy_android.R
import com.magks.savvy_android.ViewModels.ToolbarViewModel

class ProfileActivity : AppCompatActivity() {


    val toolbarViewModel = ViewModelProviders.of(this).get(ToolbarViewModel::class.java)

    override  fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Fullscreen
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // Toolbar
        val toolbar = findViewById<Toolbar>(R.id.game_dashboard_toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        // Display
        setContentView(R.layout.activity_profile)
    }

    override fun onDestroy() {
        super.onDestroy()
        // Update toolbar
        toolbarViewModel.isLeavingProfileActivity()
    }
}
