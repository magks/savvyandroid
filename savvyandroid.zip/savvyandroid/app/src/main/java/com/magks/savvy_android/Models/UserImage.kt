package com.magks.savvy_android.Models


abstract class UserImage {
    abstract var id: String
    abstract var user_id: String
    abstract var image_path: String
    abstract var priority: Int
    abstract var thumb_path: String
}