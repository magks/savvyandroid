package com.magks.savvy_android.ViewModels

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel;
import com.magks.savvy_android.util.ObservableViewModel

class ToolbarViewModel :ViewModel() {
    private val _onProfileActivity =  MutableLiveData<Boolean>()
    val onProfileActivity : LiveData<Boolean> = _onProfileActivity

    init {
        _onProfileActivity.value = false
    }

    fun isLeavingProfileActivity() {
        _onProfileActivity.value = false
    }

    fun isEnteringProfileActivity() {
        _onProfileActivity.value = true
    }
}
